<?php session_start()?>
<html>
	<body>
			<?php 
			$cn=mysqli_connect("localhost","root","","vastra") or die ("check connection");
			$product_name=$_POST['product_name'];
			$product_price=$_POST['product_price'];
			$description=$_POST['description'];
			$product_size=$_POST['product_size'];
			$category_id=$_POST['category_id'];
			$subcategory_id=$_POST['subcategory_id'];
			$sql="insert into product (product_name,product_price,description,product_size,category_id,subcategory_id)values ('$product_name','$product_price','$description','$product_size','$category_id','$subcategory_id')";
			$result=mysqli_query($cn,$sql);
			$_SESSION['msg']="product inserted";
			//header("Location:product.php");
		?>
		</body>
	</html>
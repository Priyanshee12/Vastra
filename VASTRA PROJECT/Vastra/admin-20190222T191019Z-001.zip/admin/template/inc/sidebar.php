  <div class="col-md-3">
                    <div class="list-group">
                      <a href="index.html" class="list-group-item active">
                        <i class="fa fa-tachometer"></i> Dashboard
                      </a>
                      <a href="country.php" class="list-group-item">
                          <span class="badge"></span>
                          <i class="fa fa-file-text"></i> Country
                      </a>
                      <a href="state.php" class="list-group-item">
                          <span class="badge"></span>
                          <i class="fa fa-comment"></i> State  
                      </a>
                      <a href="city.php" class="list-group-item">
                          <span class="badge"></span>
                          <i class="fa fa-folder-open"></i> City
                      </a>
                      <a href="brand.php" class="list-group-item">
                          <span class="badge"></span>
                          <i class="fa fa-users"></i> Brand
                      </a>
  			<a href="subcategory.php" class="list-group-item">
                          <span class="badge"></span>
                          <i class="fa fa-file-text"></i> SubCategory
                      </a>
			 <a href="product.php" class="list-group-item">
                          <span class="badge"></span>
                          <i class="fa fa-comment"></i> Product  
                      </a>
                      <a href="category_report.php" class="list-group-item">
                          <span class="badge"></span>
                          <i class="fa fa-file-text"></i> Category Report
                      </a>

                      <a href="brand_report.php" class="list-group-item">
                          <span class="badge"></span>
                          <i class="fa fa-file-text"></i> Brand Report
                      </a>
                  
                    </div>
                </div>
